package com.kingsley.slearnoauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SlearnOauthApplicationTests {

	@Test
	void contextLoads() {
	}

}
