package com.kingsley.authproviderdemo.authproviderdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthproviderdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuthproviderdemoApplication.class, args);
	}

}
