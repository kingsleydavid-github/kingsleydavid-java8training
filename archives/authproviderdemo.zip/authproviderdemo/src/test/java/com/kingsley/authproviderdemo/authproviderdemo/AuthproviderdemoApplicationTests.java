package com.kingsley.authproviderdemo.authproviderdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthproviderdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
