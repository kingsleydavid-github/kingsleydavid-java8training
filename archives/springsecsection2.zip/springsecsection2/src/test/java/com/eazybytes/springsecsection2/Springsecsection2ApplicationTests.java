package com.eazybytes.springsecsection2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springsecsection2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
