package com.kingsley.orders.handler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

@Configuration
public class OrdersHandlerInterceptor implements HandlerInterceptor {

	@Autowired
	RestTemplate restTemplate;
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		// TODO Auto-generated method stub
		// return HandlerInterceptor.super.preHandle(request, response, handler);
		boolean isAuthenticated = false;
		
		String auth = request.getHeader("Authorization");
		if(auth != null && !auth.isEmpty() && auth.startsWith("Bearer"))
		{
			String token = auth.substring(7);
			System.out.println(token);

			String authResourceUrl = "http://localhost:3000/";
			ResponseEntity<String> resp = restTemplate.postForEntity(authResourceUrl + "/validateToken", token, String.class);
			
			if(resp.getStatusCode().equals(HttpStatus.OK))
			{
				String respBody = resp.getBody();
				if(respBody.equals("Valid"))
				{
					isAuthenticated = true;
				}
			} else if(resp.getStatusCode().equals(HttpStatus.UNAUTHORIZED))
			{			
				isAuthenticated = false;
				response.setStatus(HttpStatus.UNAUTHORIZED.value());
				response.sendError(HttpStatus.UNAUTHORIZED.value(), "Unauthorized Request");
			}
		} else {
			response.setStatus(HttpStatus.UNAUTHORIZED.value());
			response.sendError(HttpStatus.UNAUTHORIZED.value(), "Unauthorized Request");
		}
		return isAuthenticated;
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		// TODO Auto-generated method stub
		HandlerInterceptor.super.postHandle(request, response, handler, modelAndView);
	}

	
	
}
