package com.kingsley.imauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImAuthApplicationTests {

	@Test
	void contextLoads() {
	}

}
