package com.kingsley.sblearn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SblearnApplication {

	public static void main(String[] args) {
		SpringApplication.run(SblearnApplication.class, args);
	}

}
