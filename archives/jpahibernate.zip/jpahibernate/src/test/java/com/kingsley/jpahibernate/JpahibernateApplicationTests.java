package com.kingsley.jpahibernate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpahibernateApplicationTests {

	@Test
	void contextLoads() {
	}

}
