package com.kingsley.orderhistory.orderhistory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderhistoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
