package com.mphasis.kingsley.mphasisbookskingsley;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MphasisbooksKingsleyApplicationTests {

	@Test
	void contextLoads() {
	}

}
